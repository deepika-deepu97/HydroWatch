# Microservices Architecture
1. **Eureka Server** (`com.waterleak.eureka`): Port 8761
2. **API Gateway** (`com.waterleak.gateway`): Port 8080 - JWT verification & route filters
3. **Identity Service** (`com.waterleak.identity`): Port 8081 - Issues HMAC-SHA256 JWT tokens
4. **MeterSeries Service** (`com.waterleak.meterseries`): Port 8082 - Meter series storage & CSV parser
5. **Baseline Service** (`com.waterleak.baseline`): Port 8083 - 01:00-05:00 night baseline & Kafka publisher
6. **LeakCase Service** (`com.waterleak.leakcase`): Port 8084 - Kafka consumer & case workflow state
