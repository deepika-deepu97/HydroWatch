# JWT & Record Authorization
Signed with HMAC-SHA256.
Claims:
- `sub`: username
- `userId`: UUID
- `role`: RESIDENT / UTILITY_ANALYST
- `properties`: allowed property IDs (or '*' for analysts)

Gateway extracts and injects:
- `X-User-Id`
- `X-User-Role`
- `X-User-Properties`
