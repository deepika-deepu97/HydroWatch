# Baseline Detection Math & Critical Test Specification

$$\\Delta\\% = \\frac{\\text{Flow}_{observed} - \\text{Baseline}}{\\text{Baseline}} \\times 100$$

## Verification:
- Home A: Baseline = 10, Flow = 35 -> Deviation = 250% >= 50% -> FLAGGED
- Home B: Baseline = 30, Flow = 35 -> Deviation = 16.67% < 50% -> NOT FLAGGED
