# REST API Specs (Gateway 8080)
- `POST /api/v1/auth/login`
- `GET /api/v1/auth/me`
- `GET /api/v1/properties`
- `GET /api/v1/readings/property/{propertyId}`
- `POST /api/v1/readings/csv-upload`
- `GET /api/v1/baselines/property/{propertyId}`
- `POST /api/v1/baselines/evaluate`
- `GET /api/v1/cases`
- `PATCH /api/v1/cases/{caseId}/status`
