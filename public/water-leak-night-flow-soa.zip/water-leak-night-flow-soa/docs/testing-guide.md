# Testing Guide
Run `mvn clean test` in `backend/` to execute:
- `BaselineEvaluationServiceTest`: Critical domain rule test for Home A vs Home B.
- `PropertyAuthorizationTest`: Resident access vs 403 Forbidden enforcement.
- `AnomalyEventConsumerTest`: Idempotency and duplicate Kafka event rejection.
- `JwtServiceTest`: Token signing, validation, claims extraction.
