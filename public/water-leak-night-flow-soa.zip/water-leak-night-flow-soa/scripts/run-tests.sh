#!/bin/bash
cd backend && mvn clean test
