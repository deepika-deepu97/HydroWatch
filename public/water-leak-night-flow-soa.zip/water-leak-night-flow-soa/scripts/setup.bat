@echo off
echo Setting up Water Leak Night-Flow Baseline Detection SOA...
cd frontend
call npm install
cd ..
cd backend
call mvn clean install -DskipTests
cd ..
echo Setup completed!
