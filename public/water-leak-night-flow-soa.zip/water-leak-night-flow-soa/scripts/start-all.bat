@echo off
echo Starting stack...
start "Eureka" cmd /k "cd backend\\eureka-server && mvn spring-boot:run"
start "Gateway" cmd /k "cd backend\\api-gateway && mvn spring-boot:run"
start "Identity" cmd /k "cd backend\\identity-service && mvn spring-boot:run"
start "MeterSeries" cmd /k "cd backend\\meter-series-service && mvn spring-boot:run"
start "Baseline" cmd /k "cd backend\\baseline-service && mvn spring-boot:run"
start "LeakCase" cmd /k "cd backend\\leak-case-service && mvn spring-boot:run"
start "Frontend" cmd /k "cd frontend && npm run dev"
echo Stack initialized.
