@echo off
cd backend
call mvn clean test
cd ..
