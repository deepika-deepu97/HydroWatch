#!/bin/bash
set -e
cd frontend && npm install && cd ..
cd backend && mvn clean install -DskipTests && cd ..
echo "Setup complete!"
