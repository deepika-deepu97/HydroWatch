\connect meter_series_db;

CREATE TABLE IF NOT EXISTS properties (
    id VARCHAR(64) PRIMARY KEY,
    address VARCHAR(255) NOT NULL,
    property_type VARCHAR(64) NOT NULL,
    zone_name VARCHAR(64) NOT NULL,
    meter_serial_number VARCHAR(100) UNIQUE NOT NULL,
    resident_user_id VARCHAR(64),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS meter_readings (
    id VARCHAR(64) PRIMARY KEY,
    property_id VARCHAR(64) NOT NULL REFERENCES properties(id),
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
    hour_of_day INT NOT NULL,
    flow_rate_units_per_hour NUMERIC(10, 2) NOT NULL,
    reading_type VARCHAR(32) NOT NULL,
    battery_level INT DEFAULT 98,
    quality_flag VARCHAR(32) DEFAULT 'OK',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_readings_property_time ON meter_readings(property_id, timestamp);
CREATE INDEX IF NOT EXISTS idx_readings_hour ON meter_readings(hour_of_day);

INSERT INTO properties (id, address, property_type, zone_name, meter_serial_number, resident_user_id)
VALUES 
('PROP-HOME-A', '742 Evergreen Terrace, Sector 4', 'RESIDENTIAL_SINGLE_FAMILY', 'North Zone', 'MTR-882109', 'usr-resident-001'),
('PROP-HOME-B', '1004 Willow Creek Lane, Sector 9', 'RESIDENTIAL_SINGLE_FAMILY', 'South Zone', 'MTR-994311', 'usr-resident-002'),
('PROP-COMM-C', '55 Industrial Parkway, Sector 2', 'COMMERCIAL_OFFICE', 'Central Zone', 'MTR-441022', 'usr-analyst-001');
