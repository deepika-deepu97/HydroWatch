CREATE DATABASE identity_db;
CREATE USER identity_user WITH ENCRYPTED PASSWORD 'identity_password';
GRANT ALL PRIVILEGES ON DATABASE identity_db TO identity_user;

CREATE DATABASE meter_series_db;
CREATE USER meter_user WITH ENCRYPTED PASSWORD 'meter_password';
GRANT ALL PRIVILEGES ON DATABASE meter_series_db TO meter_user;

CREATE DATABASE baseline_db;
CREATE USER baseline_user WITH ENCRYPTED PASSWORD 'baseline_password';
GRANT ALL PRIVILEGES ON DATABASE baseline_db TO baseline_user;

CREATE DATABASE leak_case_db;
CREATE USER leak_user WITH ENCRYPTED PASSWORD 'leak_password';
GRANT ALL PRIVILEGES ON DATABASE leak_case_db TO leak_user;
