\connect baseline_db;

CREATE TABLE IF NOT EXISTS property_baselines (
    id VARCHAR(64) PRIMARY KEY,
    property_id VARCHAR(64) UNIQUE NOT NULL,
    baseline_flow_units_per_hour NUMERIC(10, 2) NOT NULL,
    window_start_hour INT DEFAULT 1,
    window_end_hour INT DEFAULT 5,
    sample_readings_count INT NOT NULL,
    deviation_threshold_percent NUMERIC(5, 2) DEFAULT 50.00,
    calculation_method VARCHAR(64) DEFAULT 'MEDIAN_NIGHT_FLOW_30D',
    status VARCHAR(32) DEFAULT 'ACTIVE',
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO property_baselines (id, property_id, baseline_flow_units_per_hour, sample_readings_count, deviation_threshold_percent)
VALUES 
('BASE-HOME-A', 'PROP-HOME-A', 10.00, 120, 50.00),
('BASE-HOME-B', 'PROP-HOME-B', 30.00, 120, 50.00),
('BASE-COMM-C', 'PROP-COMM-C', 65.00, 120, 50.00);
