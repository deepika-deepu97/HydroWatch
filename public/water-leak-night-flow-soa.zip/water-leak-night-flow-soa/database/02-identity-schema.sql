\connect identity_db;

CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(64) PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(120) NOT NULL,
    role VARCHAR(32) NOT NULL,
    authorized_properties TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO users (id, username, email, password_hash, full_name, role, authorized_properties)
VALUES 
('usr-analyst-001', 'analyst@utility.gov', 'analyst@utility.gov', '$2a$10$e8wFp1P/Jd8mYvKzRzWc2eRzE8x4b5L6f7g8h9j0k1l2m3n4o5p6q', 'Marcus Vance (Lead Analyst)', 'UTILITY_ANALYST', '*'),
('usr-resident-001', 'alice@home-a.com', 'alice@home-a.com', '$2a$10$e8wFp1P/Jd8mYvKzRzWc2eRzE8x4b5L6f7g8h9j0k1l2m3n4o5p6q', 'Alice Chen (Home A Owner)', 'RESIDENT', 'PROP-HOME-A'),
('usr-resident-002', 'bob@home-b.com', 'bob@home-b.com', '$2a$10$e8wFp1P/Jd8mYvKzRzWc2eRzE8x4b5L6f7g8h9j0k1l2m3n4o5p6q', 'Bob Davis (Home B Owner)', 'RESIDENT', 'PROP-HOME-B');
