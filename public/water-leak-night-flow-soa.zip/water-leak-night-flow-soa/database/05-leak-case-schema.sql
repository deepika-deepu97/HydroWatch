\connect leak_case_db;

CREATE TABLE IF NOT EXISTS processed_events (
    event_id VARCHAR(128) PRIMARY KEY,
    event_type VARCHAR(64) NOT NULL,
    received_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS investigation_cases (
    case_id VARCHAR(64) PRIMARY KEY,
    property_id VARCHAR(64) NOT NULL,
    event_id VARCHAR(128) NOT NULL,
    status VARCHAR(32) NOT NULL,
    severity VARCHAR(32) NOT NULL,
    observed_flow NUMERIC(10, 2) NOT NULL,
    baseline_value NUMERIC(10, 2) NOT NULL,
    deviation_percent NUMERIC(8, 2) NOT NULL,
    detected_at TIMESTAMP WITH TIME ZONE NOT NULL,
    assigned_analyst VARCHAR(100),
    work_order_number VARCHAR(64),
    detection_reason TEXT,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_cases_property ON investigation_cases(property_id);
CREATE INDEX IF NOT EXISTS idx_cases_status ON investigation_cases(status);
