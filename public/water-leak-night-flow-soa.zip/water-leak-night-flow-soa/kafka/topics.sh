#!/bin/bash
BOOTSTRAP_SERVER=${KAFKA_BOOTSTRAP_SERVERS:-"localhost:9092"}
TOPIC_NAME="soa.s10.t02.events"

kafka-topics --bootstrap-server "$BOOTSTRAP_SERVER" \
  --create --if-not-exists \
  --topic "$TOPIC_NAME" \
  --partitions 3 \
  --replication-factor 1
