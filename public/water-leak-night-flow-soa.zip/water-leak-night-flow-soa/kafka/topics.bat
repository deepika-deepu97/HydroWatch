@echo off
set BOOTSTRAP_SERVER=%KAFKA_BOOTSTRAP_SERVERS%
if "%BOOTSTRAP_SERVER%"=="" set BOOTSTRAP_SERVER=localhost:9092
kafka-topics.bat --bootstrap-server %BOOTSTRAP_SERVER% --create --if-not-exists --topic soa.s10.t02.events --partitions 3 --replication-factor 1
