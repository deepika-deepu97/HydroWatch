const API_BASE = '/api/v1';

export const api = {
  async login(username, password) {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    if (!res.ok) throw new Error('Invalid credentials');
    return res.json();
  },

  async getProperties(token) {
    const res = await fetch(`${API_BASE}/properties`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    return res.json();
  },

  async getReadings(token, propertyId) {
    const res = await fetch(`${API_BASE}/readings/property/${propertyId}`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    return res.json();
  },

  async getBaseline(token, propertyId) {
    const res = await fetch(`${API_BASE}/baselines/property/${propertyId}`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    return res.json();
  },

  async getCases(token) {
    const res = await fetch(`${API_BASE}/cases`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    return res.json();
  },

  async updateCaseStatus(token, caseId, status, notes) {
    const res = await fetch(`${API_BASE}/cases/${caseId}/status`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({ status, notes })
    });
    return res.json();
  }
};
