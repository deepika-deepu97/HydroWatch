import React, { useState, useEffect } from 'react';
import { api } from './services/api';

export default function App() {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="border-b border-slate-200 bg-white px-6 py-4">
        <h1 className="text-xl font-bold text-sky-800">Water Leak Night-Flow Baseline Detection SOA</h1>
      </header>
      <main className="p-6 max-w-7xl mx-auto">
        <p className="text-sm text-slate-600">Frontend Client connected to Spring Cloud API Gateway.</p>
      </main>
    </div>
  );
}
