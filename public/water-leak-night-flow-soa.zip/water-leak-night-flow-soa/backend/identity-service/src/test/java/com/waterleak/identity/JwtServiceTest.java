package com.waterleak.identity;

import com.waterleak.identity.model.Role;
import com.waterleak.identity.model.User;
import com.waterleak.identity.service.JwtService;
import io.jsonwebtoken.Claims;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import static org.assertj.core.api.Assertions.assertThat;

class JwtServiceTest {

    private JwtService jwtService;

    @BeforeEach
    void setUp() {
        jwtService = new JwtService();
        ReflectionTestUtils.setField(jwtService, "jwtSecret", "404E635266556A586E3272357538782F413F4428472B4B6250645367566B5970");
        ReflectionTestUtils.setField(jwtService, "jwtExpirationMs", 3600000L);
    }

    @Test
    void shouldGenerateAndExtractClaimsForResident() {
        User user = new User("usr-test-1", "alice@home.com", "alice@home.com", "hash", "Alice", Role.RESIDENT, "PROP-HOME-A");
        String token = jwtService.generateToken(user);

        assertThat(token).isNotBlank();
        assertThat(jwtService.validateToken(token)).isTrue();

        Claims claims = jwtService.extractClaims(token);
        assertThat(claims.getSubject()).isEqualTo("alice@home.com");
        assertThat(claims.get("userId", String.class)).isEqualTo("usr-test-1");
        assertThat(claims.get("role", String.class)).isEqualTo("RESIDENT");
        assertThat(claims.get("properties", String.class)).isEqualTo("PROP-HOME-A");
    }

    @Test
    void shouldGenerateTokenForUtilityAnalystWithWildcardProperties() {
        User user = new User("usr-test-2", "marcus@utility.gov", "marcus@utility.gov", "hash", "Marcus", Role.UTILITY_ANALYST, "*");
        String token = jwtService.generateToken(user);

        Claims claims = jwtService.extractClaims(token);
        assertThat(claims.get("role", String.class)).isEqualTo("UTILITY_ANALYST");
        assertThat(claims.get("properties", String.class)).isEqualTo("*");
    }
}
