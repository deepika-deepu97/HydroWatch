package com.waterleak.leakcase.controller;

import com.waterleak.leakcase.model.CaseStatus;
import com.waterleak.leakcase.model.InvestigationCase;
import com.waterleak.leakcase.repository.InvestigationCaseRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/cases")
public class InvestigationCaseController {
    private final InvestigationCaseRepository caseRepository;

    public InvestigationCaseController(InvestigationCaseRepository caseRepository) {
        this.caseRepository = caseRepository;
    }

    @GetMapping
    public ResponseEntity<List<InvestigationCase>> getCases(
            @RequestHeader(value = "X-User-Role", required = false) String role,
            @RequestHeader(value = "X-User-Properties", required = false) String allowedProps
    ) {
        if ("UTILITY_ANALYST".equalsIgnoreCase(role) || "*".equals(allowedProps)) {
            return ResponseEntity.ok(caseRepository.findAllByOrderByDetectedAtDesc());
        }
        if (allowedProps != null && !allowedProps.isBlank()) {
            String propId = allowedProps.split(",")[0].trim();
            return ResponseEntity.ok(caseRepository.findByPropertyIdOrderByDetectedAtDesc(propId));
        }
        return ResponseEntity.ok(List.of());
    }

    @PatchMapping("/{caseId}/status")
    public ResponseEntity<?> updateStatus(
            @PathVariable String caseId,
            @RequestBody Map<String, String> body,
            @RequestHeader(value = "X-User-Role", required = false) String role
    ) {
        if (!"UTILITY_ANALYST".equalsIgnoreCase(role)) {
            return ResponseEntity.status(403).body(Map.of("error", "Forbidden: Only utility analysts can change case status"));
        }

        InvestigationCase c = caseRepository.findById(caseId)
                .orElseThrow(() -> new RuntimeException("Case not found"));

        if (body.containsKey("status")) {
            c.setStatus(CaseStatus.valueOf(body.get("status")));
        }
        if (body.containsKey("notes")) {
            c.setNotes(body.get("notes"));
        }
        if (body.containsKey("workOrderNumber")) {
            c.setWorkOrderNumber(body.get("workOrderNumber"));
        }
        c.setUpdatedAt(Instant.now());
        return ResponseEntity.ok(caseRepository.save(c));
    }
}
