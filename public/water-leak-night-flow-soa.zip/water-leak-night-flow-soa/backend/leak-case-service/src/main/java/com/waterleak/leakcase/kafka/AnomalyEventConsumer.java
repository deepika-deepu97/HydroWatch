package com.waterleak.leakcase.kafka;

import com.waterleak.leakcase.model.CaseStatus;
import com.waterleak.leakcase.model.InvestigationCase;
import com.waterleak.leakcase.model.ProcessProcessedEvent;
import com.waterleak.leakcase.model.Severity;
import com.waterleak.leakcase.repository.InvestigationCaseRepository;
import com.waterleak.leakcase.repository.ProcessedEventRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;

@Component
public class AnomalyEventConsumer {
    private static final Logger log = LoggerFactory.getLogger(AnomalyEventConsumer.class);

    private final InvestigationCaseRepository caseRepository;
    private final ProcessedEventRepository eventRepository;

    public AnomalyEventConsumer(InvestigationCaseRepository caseRepository, ProcessedEventRepository eventRepository) {
        this.caseRepository = caseRepository;
        this.eventRepository = eventRepository;
    }

    @KafkaListener(topics = "${app.kafka.topic:soa.s10.t02.events}", groupId = "leak-case-group")
    @Transactional
    public void consumeAnomalyEvent(Map<String, Object> event) {
        String eventId = (String) event.get("eventId");
        log.info("Received NightFlowAnomalyDetected event: {}", eventId);

        // IDEMPOTENCY CHECK: Guard against duplicate event processing
        if (eventId != null && eventRepository.existsByEventId(eventId)) {
            log.warn("Duplicate event {} ignored. Idempotency guaranteed.", eventId);
            return;
        }

        String propertyId = (String) event.get("propertyId");
        BigDecimal observedFlow = new BigDecimal(event.get("observedFlow").toString());
        BigDecimal baselineValue = new BigDecimal(event.get("baselineValue").toString());
        BigDecimal deviation = new BigDecimal(event.get("deviation").toString());
        String severityStr = (String) event.get("severity");
        String reason = (String) event.get("reason");

        Severity severity = Severity.valueOf(severityStr != null ? severityStr.toUpperCase() : "MEDIUM");

        InvestigationCase newCase = new InvestigationCase(
                "CASE-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase(),
                propertyId,
                eventId != null ? eventId : "evt-unknown",
                CaseStatus.NEW,
                severity,
                observedFlow,
                baselineValue,
                deviation,
                Instant.now(),
                reason
        );

        caseRepository.save(newCase);
        if (eventId != null) {
            eventRepository.save(new ProcessProcessedEvent(eventId, "NightFlowAnomalyDetected"));
        }
        log.info("Successfully created investigation case: {} for property: {}", newCase.getCaseId(), propertyId);
    }
}
