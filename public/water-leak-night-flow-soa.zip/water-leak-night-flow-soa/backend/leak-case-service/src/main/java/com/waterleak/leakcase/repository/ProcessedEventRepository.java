package com.waterleak.leakcase.repository;

import com.waterleak.leakcase.model.ProcessProcessedEvent;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProcessedEventRepository extends JpaRepository<ProcessProcessedEvent, String> {
    boolean existsByEventId(String eventId);
}
