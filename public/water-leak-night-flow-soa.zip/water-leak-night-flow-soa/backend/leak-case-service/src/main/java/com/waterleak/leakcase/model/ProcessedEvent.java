package com.waterleak.leakcase.model;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "processed_events")
public class ProcessProcessedEvent {
    @Id
    @Column(length = 128)
    private String eventId;

    @Column(nullable = false, length = 64)
    private String eventType;

    private Instant receivedAt = Instant.now();

    public ProcessProcessedEvent() {}
    public ProcessProcessedEvent(String eventId, String eventType) {
        this.eventId = eventId;
        this.eventType = eventType;
    }

    public String getEventId() { return eventId; }
    public void setEventId(String eventId) { this.eventId = eventId; }

    public String getEventType() { return eventType; }
    public void setEventType(String eventType) { this.eventType = eventType; }

    public Instant getReceivedAt() { return receivedAt; }
    public void setReceivedAt(Instant receivedAt) { this.receivedAt = receivedAt; }
}
