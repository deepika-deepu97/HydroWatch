package com.waterleak.leakcase.model;

public enum CaseStatus {
    NEW,
    INVESTIGATING,
    CONFIRMED_LEAK,
    REPAIRED,
    FALSE_POSITIVE,
    CLOSED
}
