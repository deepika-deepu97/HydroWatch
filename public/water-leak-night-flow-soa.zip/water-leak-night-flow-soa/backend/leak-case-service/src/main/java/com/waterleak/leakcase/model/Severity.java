package com.waterleak.leakcase.model;

public enum Severity {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}
