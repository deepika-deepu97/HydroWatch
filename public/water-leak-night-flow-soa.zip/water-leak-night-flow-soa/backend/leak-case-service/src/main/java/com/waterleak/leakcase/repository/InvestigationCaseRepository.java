package com.waterleak.leakcase.repository;

import com.waterleak.leakcase.model.InvestigationCase;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface InvestigationCaseRepository extends JpaRepository<InvestigationCase, String> {
    List<InvestigationCase> findByPropertyIdOrderByDetectedAtDesc(String propertyId);
    List<InvestigationCase> findAllByOrderByDetectedAtDesc();
}
