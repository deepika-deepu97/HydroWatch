package com.waterleak.leakcase.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "investigation_cases", indexes = {
    @Index(name = "idx_cases_property", columnList = "propertyId"),
    @Index(name = "idx_cases_status", columnList = "status")
})
public class InvestigationCase {
    @Id
    @Column(length = 64)
    private String caseId;

    @Column(nullable = false, length = 64)
    private String propertyId;

    @Column(nullable = false, length = 128)
    private String eventId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 32)
    private CaseStatus status = CaseStatus.NEW;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 32)
    private Severity severity;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal observedFlow;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal baselineValue;

    @Column(nullable = false, precision = 8, scale = 2)
    private BigDecimal deviationPercent;

    @Column(nullable = false)
    private Instant detectedAt;

    private String assignedAnalyst;
    private String workOrderNumber;

    @Column(columnDefinition = "TEXT")
    private String detectionReason;

    @Column(columnDefinition = "TEXT")
    private String notes;

    private Instant createdAt = Instant.now();
    private Instant updatedAt = Instant.now();

    public InvestigationCase() {}

    public InvestigationCase(String caseId, String propertyId, String eventId, CaseStatus status,
                             Severity severity, BigDecimal observedFlow, BigDecimal baselineValue,
                             BigDecimal deviationPercent, Instant detectedAt, String detectionReason) {
        this.caseId = caseId;
        this.propertyId = propertyId;
        this.eventId = eventId;
        this.status = status;
        this.severity = severity;
        this.observedFlow = observedFlow;
        this.baselineValue = baselineValue;
        this.deviationPercent = deviationPercent;
        this.detectedAt = detectedAt;
        this.detectionReason = detectionReason;
    }

    public String getCaseId() { return caseId; }
    public void setCaseId(String caseId) { this.caseId = caseId; }

    public String getPropertyId() { return propertyId; }
    public void setPropertyId(String propertyId) { this.propertyId = propertyId; }

    public String getEventId() { return eventId; }
    public void setEventId(String eventId) { this.eventId = eventId; }

    public CaseStatus getStatus() { return status; }
    public void setStatus(CaseStatus status) { this.status = status; }

    public Severity getSeverity() { return severity; }
    public void setSeverity(Severity severity) { this.severity = severity; }

    public BigDecimal getObservedFlow() { return observedFlow; }
    public void setObservedFlow(BigDecimal observedFlow) { this.observedFlow = observedFlow; }

    public BigDecimal getBaselineValue() { return baselineValue; }
    public void setBaselineValue(BigDecimal baselineValue) { this.baselineValue = baselineValue; }

    public BigDecimal getDeviationPercent() { return deviationPercent; }
    public void setDeviationPercent(BigDecimal deviationPercent) { this.deviationPercent = deviationPercent; }

    public Instant getDetectedAt() { return detectedAt; }
    public void setDetectedAt(Instant detectedAt) { this.detectedAt = detectedAt; }

    public String getAssignedAnalyst() { return assignedAnalyst; }
    public void setAssignedAnalyst(String assignedAnalyst) { this.assignedAnalyst = assignedAnalyst; }

    public String getWorkOrderNumber() { return workOrderNumber; }
    public void setWorkOrderNumber(String workOrderNumber) { this.workOrderNumber = workOrderNumber; }

    public String getDetectionReason() { return detectionReason; }
    public void setDetectionReason(String detectionReason) { this.detectionReason = detectionReason; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }

    public Instant getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(Instant updatedAt) { this.updatedAt = updatedAt; }
}
