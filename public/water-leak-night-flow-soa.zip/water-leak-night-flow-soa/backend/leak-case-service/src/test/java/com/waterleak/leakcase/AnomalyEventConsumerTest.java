package com.waterleak.leakcase;

import com.waterleak.leakcase.kafka.AnomalyEventConsumer;
import com.waterleak.leakcase.model.InvestigationCase;
import com.waterleak.leakcase.repository.InvestigationCaseRepository;
import com.waterleak.leakcase.repository.ProcessedEventRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

class AnomalyEventConsumerTest {

    private InvestigationCaseRepository caseRepository;
    private ProcessedEventRepository eventRepository;
    private AnomalyEventConsumer consumer;

    @BeforeEach
    void setUp() {
        caseRepository = Mockito.mock(InvestigationCaseRepository.class);
        eventRepository = Mockito.mock(ProcessedEventRepository.class);
        consumer = new AnomalyEventConsumer(caseRepository, eventRepository);
    }

    @Test
    void shouldConsumeEventAndPersistCase_WhenNotDuplicate() {
        String eventId = "evt-12345";
        when(eventRepository.existsByEventId(eventId)).thenReturn(false);

        Map<String, Object> event = new HashMap<>();
        event.put("eventId", eventId);
        event.put("propertyId", "PROP-HOME-A");
        event.put("observedFlow", "35.00");
        event.put("baselineValue", "10.00");
        event.put("deviation", "250.00");
        event.put("severity", "CRITICAL");
        event.put("reason", "Flow exceeded threshold");

        consumer.consumeAnomalyEvent(event);

        ArgumentCaptor<InvestigationCase> captor = ArgumentCaptor.forClass(InvestigationCase.class);
        verify(caseRepository, times(1)).save(captor.capture());

        InvestigationCase savedCase = captor.getValue();
        assertThat(savedCase.getPropertyId()).isEqualTo("PROP-HOME-A");
        assertThat(savedCase.getDeviationPercent()).isEqualByComparingTo(new BigDecimal("250.00"));
        assertThat(savedCase.getObservedFlow()).isEqualByComparingTo(new BigDecimal("35.00"));
    }

    @Test
    void shouldDiscardDuplicateEvent_AndGuaranteeIdempotency() {
        String eventId = "evt-duplicate-999";
        when(eventRepository.existsByEventId(eventId)).thenReturn(true);

        Map<String, Object> event = new HashMap<>();
        event.put("eventId", eventId);
        event.put("propertyId", "PROP-HOME-A");
        event.put("observedFlow", "35.00");
        event.put("baselineValue", "10.00");
        event.put("deviation", "250.00");

        consumer.consumeAnomalyEvent(event);

        // Verify that NO case is saved again for duplicate event!
        verify(caseRepository, never()).save(any());
    }
}
