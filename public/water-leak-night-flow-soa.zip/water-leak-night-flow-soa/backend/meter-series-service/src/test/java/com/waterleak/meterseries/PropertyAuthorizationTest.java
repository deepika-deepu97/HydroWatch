package com.waterleak.meterseries;

import com.waterleak.meterseries.security.PropertyAuthorizationFilter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import static org.assertj.core.api.Assertions.assertThat;

class PropertyAuthorizationTest {

    private PropertyAuthorizationFilter filter;

    @BeforeEach
    void setUp() {
        filter = new PropertyAuthorizationFilter();
    }

    @Test
    void shouldAllowResidentAccessToOwnProperty() throws Exception {
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setRequestURI("/api/v1/readings/property/PROP-HOME-A");
        request.addHeader("X-User-Role", "RESIDENT");
        request.addHeader("X-User-Properties", "PROP-HOME-A");

        MockHttpServletResponse response = new MockHttpServletResponse();
        MockFilterChain chain = new MockFilterChain();

        filter.doFilter(request, response, chain);

        assertThat(response.getStatus()).isEqualTo(200);
    }

    @Test
    void shouldDenyResidentAccessToAnotherResidentPropertyWith403() throws Exception {
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setRequestURI("/api/v1/readings/property/PROP-HOME-B"); // Attempting to spy on Home B
        request.addHeader("X-User-Role", "RESIDENT");
        request.addHeader("X-User-Properties", "PROP-HOME-A"); // Only authorized for Home A

        MockHttpServletResponse response = new MockHttpServletResponse();
        MockFilterChain chain = new MockFilterChain();

        filter.doFilter(request, response, chain);

        assertThat(response.getStatus()).isEqualTo(403);
        assertThat(response.getContentAsString()).contains("Forbidden: Access Denied");
    }

    @Test
    void shouldAllowUtilityAnalystAccessToAnyProperty() throws Exception {
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setRequestURI("/api/v1/readings/property/PROP-HOME-B");
        request.addHeader("X-User-Role", "UTILITY_ANALYST");
        request.addHeader("X-User-Properties", "*");

        MockHttpServletResponse response = new MockHttpServletResponse();
        MockFilterChain chain = new MockFilterChain();

        filter.doFilter(request, response, chain);

        assertThat(response.getStatus()).isEqualTo(200);
    }
}
