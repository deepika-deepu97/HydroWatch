package com.waterleak.meterseries.security;

import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@Component
public class PropertyAuthorizationFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        String path = httpRequest.getRequestURI();
        String role = httpRequest.getHeader("X-User-Role");
        String authorizedProps = httpRequest.getHeader("X-User-Properties");

        // Allow actuator or public health checks
        if (path.startsWith("/actuator")) {
            chain.doFilter(request, response);
            return;
        }

        // Utility analysts have unrestricted access to all properties
        if ("UTILITY_ANALYST".equalsIgnoreCase(role) || "*".equals(authorizedProps)) {
            chain.doFilter(request, response);
            return;
        }

        // Residents are strictly validated against their authorized property ID
        if ("RESIDENT".equalsIgnoreCase(role)) {
            if (path.contains("/property/")) {
                String requestedPropId = path.substring(path.indexOf("/property/") + 10);
                if (requestedPropId.contains("/")) {
                    requestedPropId = requestedPropId.substring(0, requestedPropId.indexOf("/"));
                }

                List<String> allowedList = authorizedProps != null ? Arrays.asList(authorizedProps.split(",")) : List.of();
                if (!allowedList.contains(requestedPropId)) {
                    httpResponse.setStatus(HttpServletResponse.SC_FORBIDDEN);
                    httpResponse.setContentType("application/json");
                    httpResponse.getWriter().write("{\"error\": \"Forbidden: Access Denied. Resident is not authorized for property " + requestedPropId + "\"}");
                    return;
                }
            }
        }

        chain.doFilter(request, response);
    }
}
