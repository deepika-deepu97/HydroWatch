package com.waterleak.meterseries.model;

public enum ReadingType {
    REAL,
    SIMULATED
}
