package com.waterleak.meterseries.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "meter_readings", indexes = {
    @Index(name = "idx_readings_prop_time", columnList = "propertyId, timestamp")
})
public class MeterReading {
    @Id
    @Column(length = 64)
    private String id;

    @Column(nullable = false, length = 64)
    private String propertyId;

    @Column(nullable = false)
    private Instant timestamp;

    @Column(nullable = false)
    private int hourOfDay;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal flowRateUnitsPerHour;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 32)
    private ReadingType readingType = ReadingType.REAL;

    private int batteryLevel = 98;
    private String qualityFlag = "OK";
    private Instant createdAt = Instant.now();

    public MeterReading() {}
    public MeterReading(String id, String propertyId, Instant timestamp, int hourOfDay, BigDecimal flowRateUnitsPerHour, ReadingType readingType) {
        this.id = id;
        this.propertyId = propertyId;
        this.timestamp = timestamp;
        this.hourOfDay = hourOfDay;
        this.flowRateUnitsPerHour = flowRateUnitsPerHour;
        this.readingType = readingType;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getPropertyId() { return propertyId; }
    public void setPropertyId(String propertyId) { this.propertyId = propertyId; }

    public Instant getTimestamp() { return timestamp; }
    public void setTimestamp(Instant timestamp) { this.timestamp = timestamp; }

    public int getHourOfDay() { return hourOfDay; }
    public void setHourOfDay(int hourOfDay) { this.hourOfDay = hourOfDay; }

    public BigDecimal getFlowRateUnitsPerHour() { return flowRateUnitsPerHour; }
    public void setFlowRateUnitsPerHour(BigDecimal flowRateUnitsPerHour) { this.flowRateUnitsPerHour = flowRateUnitsPerHour; }

    public ReadingType getReadingType() { return readingType; }
    public void setReadingType(ReadingType readingType) { this.readingType = readingType; }

    public int getBatteryLevel() { return batteryLevel; }
    public void setBatteryLevel(int batteryLevel) { this.batteryLevel = batteryLevel; }

    public String getQualityFlag() { return qualityFlag; }
    public void setQualityFlag(String qualityFlag) { this.qualityFlag = qualityFlag; }

    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }
}
