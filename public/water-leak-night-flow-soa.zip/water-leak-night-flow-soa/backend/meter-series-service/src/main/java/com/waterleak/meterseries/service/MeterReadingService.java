package com.waterleak.meterseries.service;

import com.waterleak.meterseries.model.MeterReading;
import com.waterleak.meterseries.model.ReadingType;
import com.waterleak.meterseries.repository.MeterReadingRepository;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class MeterReadingService {
    private final MeterReadingRepository readingRepository;

    public MeterReadingService(MeterReadingRepository readingRepository) {
        this.readingRepository = readingRepository;
    }

    public MeterReading recordReading(MeterReading reading) {
        if (reading.getId() == null) {
            reading.setId("MTR-READ-" + UUID.randomUUID());
        }
        if (reading.getTimestamp() == null) {
            reading.setTimestamp(Instant.now());
        }
        ZonedDateTime zdt = reading.getTimestamp().atZone(ZoneOffset.UTC);
        reading.setHourOfDay(zdt.getHour());
        return readingRepository.save(reading);
    }

    public List<MeterReading> getPropertyReadings(String propertyId) {
        return readingRepository.findByPropertyIdOrderByTimestampDesc(propertyId);
    }

    public List<MeterReading> getNightWindowReadings(String propertyId, int startHour, int endHour) {
        return readingRepository.findNightWindowReadings(propertyId, startHour, endHour);
    }

    public List<MeterReading> parseAndSaveCsv(InputStream inputStream) {
        List<MeterReading> list = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
            String line;
            boolean firstLine = true;
            while ((line = reader.readLine()) != null) {
                if (firstLine) {
                    firstLine = false;
                    continue; // Skip CSV header
                }
                String[] parts = line.split(",");
                if (parts.length >= 3) {
                    String propId = parts[0].trim();
                    Instant time = Instant.parse(parts[1].trim());
                    BigDecimal flow = new BigDecimal(parts[2].trim());
                    ReadingType type = parts.length > 3 ? ReadingType.valueOf(parts[3].trim()) : ReadingType.REAL;

                    ZonedDateTime zdt = time.atZone(ZoneOffset.UTC);
                    MeterReading reading = new MeterReading(
                            "CSV-" + UUID.randomUUID(),
                            propId,
                            time,
                            zdt.getHour(),
                            flow,
                            type
                    );
                    list.add(reading);
                }
            }
        } catch (Exception ex) {
            throw new RuntimeException("Error parsing CSV: " + ex.getMessage(), ex);
        }
        return readingRepository.saveAll(list);
    }
}
