package com.waterleak.meterseries.repository;

import com.waterleak.meterseries.model.Property;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PropertyRepository extends JpaRepository<Property, String> {
    List<Property> findByResidentUserId(String residentUserId);
}
