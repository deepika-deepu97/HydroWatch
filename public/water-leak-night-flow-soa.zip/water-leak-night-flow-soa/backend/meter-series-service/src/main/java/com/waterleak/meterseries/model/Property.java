package com.waterleak.meterseries.model;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "properties")
public class Property {
    @Id
    @Column(length = 64)
    private String id;

    @Column(nullable = false)
    private String address;

    @Column(nullable = false, length = 64)
    private String propertyType;

    @Column(nullable = false, length = 64)
    private String zoneName;

    @Column(nullable = false, unique = true, length = 100)
    private String meterSerialNumber;

    @Column(length = 64)
    private String residentUserId;

    private Instant createdAt = Instant.now();

    public Property() {}
    public Property(String id, String address, String propertyType, String zoneName, String meterSerialNumber, String residentUserId) {
        this.id = id;
        this.address = address;
        this.propertyType = propertyType;
        this.zoneName = zoneName;
        this.meterSerialNumber = meterSerialNumber;
        this.residentUserId = residentUserId;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getPropertyType() { return propertyType; }
    public void setPropertyType(String propertyType) { this.propertyType = propertyType; }

    public String getZoneName() { return zoneName; }
    public void setZoneName(String zoneName) { this.zoneName = zoneName; }

    public String getMeterSerialNumber() { return meterSerialNumber; }
    public void setMeterSerialNumber(String meterSerialNumber) { this.meterSerialNumber = meterSerialNumber; }

    public String getResidentUserId() { return residentUserId; }
    public void setResidentUserId(String residentUserId) { this.residentUserId = residentUserId; }

    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }
}
