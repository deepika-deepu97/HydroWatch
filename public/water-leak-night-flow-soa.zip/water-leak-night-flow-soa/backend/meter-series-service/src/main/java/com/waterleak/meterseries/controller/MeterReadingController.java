package com.waterleak.meterseries.controller;

import com.waterleak.meterseries.model.MeterReading;
import com.waterleak.meterseries.model.Property;
import com.waterleak.meterseries.repository.PropertyRepository;
import com.waterleak.meterseries.service.MeterReadingService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class MeterReadingController {
    private final MeterReadingService readingService;
    private final PropertyRepository propertyRepository;

    public MeterReadingController(MeterReadingService readingService, PropertyRepository propertyRepository) {
        this.readingService = readingService;
        this.propertyRepository = propertyRepository;
    }

    @GetMapping("/properties")
    public ResponseEntity<List<Property>> getProperties(
            @RequestHeader(value = "X-User-Role", required = false) String role,
            @RequestHeader(value = "X-User-Properties", required = false) String allowedProps
    ) {
        if ("UTILITY_ANALYST".equalsIgnoreCase(role) || "*".equals(allowedProps)) {
            return ResponseEntity.ok(propertyRepository.findAll());
        }
        if (allowedProps != null && !allowedProps.isBlank()) {
            return ResponseEntity.ok(propertyRepository.findAllById(List.of(allowedProps.split(","))));
        }
        return ResponseEntity.ok(List.of());
    }

    @PostMapping("/readings")
    public ResponseEntity<MeterReading> recordReading(@RequestBody MeterReading reading) {
        return ResponseEntity.ok(readingService.recordReading(reading));
    }

    @GetMapping("/readings/property/{propertyId}")
    public ResponseEntity<List<MeterReading>> getReadings(@PathVariable String propertyId) {
        return ResponseEntity.ok(readingService.getPropertyReadings(propertyId));
    }

    @GetMapping("/readings/property/{propertyId}/night-window")
    public ResponseEntity<List<MeterReading>> getNightReadings(
            @PathVariable String propertyId,
            @RequestParam(defaultValue = "1") int startHour,
            @RequestParam(defaultValue = "5") int endHour
    ) {
        return ResponseEntity.ok(readingService.getNightWindowReadings(propertyId, startHour, endHour));
    }

    @PostMapping("/readings/csv-upload")
    public ResponseEntity<List<MeterReading>> uploadCsv(@RequestParam("file") MultipartFile file) throws Exception {
        return ResponseEntity.ok(readingService.parseAndSaveCsv(file.getInputStream()));
    }
}
