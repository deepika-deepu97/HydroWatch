package com.waterleak.meterseries.repository;

import com.waterleak.meterseries.model.MeterReading;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.Instant;
import java.util.List;

public interface MeterReadingRepository extends JpaRepository<MeterReading, String> {
    List<MeterReading> findByPropertyIdOrderByTimestampDesc(String propertyId);

    @Query("SELECT r FROM MeterReading r WHERE r.propertyId = :propertyId AND r.hourOfDay BETWEEN :startHour AND :endHour ORDER BY r.timestamp DESC")
    List<MeterReading> findNightWindowReadings(
            @Param("propertyId") String propertyId,
            @Param("startHour") int startHour,
            @Param("endHour") int endHour
    );
}
